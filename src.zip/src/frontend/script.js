const urlInput      = document.getElementById('url-input');
const htmlInput     = document.getElementById('html-input');
const parseBtn      = document.getElementById('parse-btn');
const step2Panel    = document.getElementById('step2-panel');
const selectorInput = document.getElementById('selector-input');
const algoSelect    = document.getElementById('algo-select');
const traverseBtn   = document.getElementById('traverse-btn');
const lcaBtn        = document.getElementById('lca-btn');
const speedSelect   = document.getElementById('speed-select');
const speedLabel    = document.getElementById('speed-label');
const limitNInput   = document.getElementById('limit-n');
const treeContainer = document.getElementById('tree-canvas');
const treeViewport  = document.getElementById('tree-viewport');
const logList       = document.getElementById('log-list');
const statsInfo     = document.getElementById('stats-info');
const zoomLabel     = document.getElementById('zoom-label');
const lcaStatusBar  = document.getElementById('lca-status-bar');
const lcaChip1      = document.getElementById('lca-chip-1');
const lcaChip2      = document.getElementById('lca-chip-2');
const lcaCancelBtn  = document.getElementById('lca-cancel-btn');

let savedHtmlSource  = "";
let currentNodesData = [];
let nodeElements     = {};
let zoomLevel        = 1.0;

// LCA state
let lcaMode          = false;
let lcaSelected      = [];   // [nodeId, nodeId]

const LOG_BITS  = 16;
let lcaParent   = [];   // lcaParent[k][v]
let lcaDepth    = [];

const ZOOM_MIN       = 0.2;
const ZOOM_MAX       = 3.0;
const ZOOM_STEP_BTN  = 0.2;
const ZOOM_STEP_WHEEL= 0.08;
const MAX_VISUAL_NODES = 2000;
const MAX_LOG_ENTRIES  = 500;

// ============ SPEED SLIDER ============
speedSelect.addEventListener('input', () => {
    speedLabel.textContent = speedSelect.value + 'ms';
});

// ============ ZOOM ============
function applyZoom() {
    treeContainer.style.transform = `scale(${zoomLevel})`;
    const baseW = parseInt(treeContainer.style.width)  || 3000;
    const baseH = parseInt(treeContainer.style.height) || 3000;
    treeContainer.style.marginRight  = (baseW * zoomLevel - baseW) + 'px';
    treeContainer.style.marginBottom = (baseH * zoomLevel - baseH) + 'px';
    zoomLabel.innerText = Math.round(zoomLevel * 100) + '%';
}

function zoomAt(newZoom, pivotX, pivotY) {
    newZoom = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, parseFloat(newZoom.toFixed(2))));
    if (newZoom === zoomLevel) return;
    const canvasX = (treeViewport.scrollLeft + pivotX) / zoomLevel;
    const canvasY = (treeViewport.scrollTop  + pivotY) / zoomLevel;
    zoomLevel = newZoom;
    applyZoom();
    treeViewport.scrollLeft = canvasX * newZoom - pivotX;
    treeViewport.scrollTop  = canvasY * newZoom - pivotY;
}

document.getElementById('zoom-in-btn').addEventListener('click', () =>
    zoomAt(zoomLevel + ZOOM_STEP_BTN, treeViewport.clientWidth / 2, treeViewport.clientHeight / 2));
document.getElementById('zoom-out-btn').addEventListener('click', () =>
    zoomAt(zoomLevel - ZOOM_STEP_BTN, treeViewport.clientWidth / 2, treeViewport.clientHeight / 2));
document.getElementById('zoom-reset-btn').addEventListener('click', () => { zoomLevel = 1.0; applyZoom(); });

treeViewport.addEventListener('wheel', (e) => {
    e.preventDefault();
    const rect = treeViewport.getBoundingClientRect();
    zoomAt(zoomLevel + (e.deltaY > 0 ? -ZOOM_STEP_WHEEL : ZOOM_STEP_WHEEL),
        e.clientX - rect.left, e.clientY - rect.top);
}, { passive: false });

// ============ PAN ============
let isPanning = false;
let panStart  = { x: 0, y: 0, sl: 0, st: 0 };

treeViewport.addEventListener('mousedown', (e) => {
    if (e.button !== 0) return;
    // Don't start pan if clicking a node in LCA mode
    if (lcaMode && e.target.classList.contains('node-container')) return;
    isPanning = true;
    panStart = { x: e.clientX, y: e.clientY, sl: treeViewport.scrollLeft, st: treeViewport.scrollTop };
    treeViewport.style.cursor = 'grabbing';
    e.preventDefault();
});
window.addEventListener('mousemove', (e) => {
    if (!isPanning) return;
    treeViewport.scrollLeft = panStart.sl - (e.clientX - panStart.x);
    treeViewport.scrollTop  = panStart.st - (e.clientY - panStart.y);
});
window.addEventListener('mouseup', () => {
    if (!isPanning) return;
    isPanning = false;
    treeViewport.style.cursor = 'grab';
});

// ============ LIMIT RADIO ============
document.querySelectorAll('input[name="limit-type"]').forEach(radio => {
    radio.addEventListener('change', () => {
        limitNInput.disabled = radio.value !== 'topn';
    });
});

// ============ PARSE ============
parseBtn.addEventListener('click', async () => {
    const url     = urlInput.value.trim();
    const rawHTML = htmlInput.value.trim();

    if (!url && !rawHTML) {
        alert("Masukkan URL atau paste HTML terlebih dahulu.");
        return;
    }

    parseBtn.innerText = "Parsing...";
    parseBtn.disabled  = true;
    treeContainer.innerHTML = '';
    zoomLevel = 1.0;
    applyZoom();
    logList.innerHTML = '<li class="log-placeholder">Menyiapkan DOM Tree...</li>';

    // Hide empty state
    const es = document.getElementById('empty-state');
    if (es) es.style.display = 'none';

    try {
        const response = await fetch('http://localhost:3000/search', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url, html: rawHTML, selector: "*", algo: "BFS" })
        });

        const result = await response.json();
        if (result.success) {
            const data = result.data;
            savedHtmlSource  = data.htmlSource || rawHTML;
            currentNodesData = data.nodes;

            if (url && data.htmlSource) htmlInput.value = data.htmlSource;

            visualizeTree(data.nodes);
            buildLCA(data.nodes);

            statsInfo.innerHTML =
                `<span class="stat-item"><svg width="12" height="12" viewBox="0 0 12 12" fill="none" style="vertical-align:middle"><circle cx="6" cy="6" r="4.5" stroke="#3d7a35" stroke-width="1.2"/></svg> Nodes: ${data.nodes.length}</span>
                 <span class="stat-divider">|</span>
                 <span class="stat-item"><svg width="12" height="12" viewBox="0 0 12 12" fill="none" style="vertical-align:middle"><path d="M6 1v10" stroke="#3d7a35" stroke-width="1.2" stroke-linecap="round"/></svg> Max Depth: ${data.maxDepth}</span>`;

            logList.innerHTML = '<li class="log-placeholder">✅ Parsing sukses! Pilih algoritma lalu klik Traverse.</li>';
            step2Panel.classList.remove('disabled');
            traverseBtn.disabled = false;
            lcaBtn.disabled      = false;
        } else {
            alert("Gagal parse: " + result.error);
        }
    } catch {
        alert("Koneksi ke backend gagal. Pastikan server sudah berjalan.");
    } finally {
        parseBtn.innerText = "Parse";
        parseBtn.disabled  = false;
    }
});

// ============ TRAVERSE ============
traverseBtn.addEventListener('click', async () => {
    const selector = selectorInput.value.trim();
    const algo     = algoSelect.value;

    if (!selector) {
        alert("Masukkan CSS Selector (contoh: div, .class, #id, a.nav)");
        return;
    }

    const limitType = document.querySelector('input[name="limit-type"]:checked').value;
    const limit     = limitType === 'topn' ? Math.max(1, parseInt(limitNInput.value) || 10) : 0;

    traverseBtn.innerText  = "Running...";
    traverseBtn.disabled   = true;
    logList.innerHTML      = '';

    resetAllNodes();

    try {
        const response = await fetch('http://localhost:3000/search', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url: "", html: savedHtmlSource, selector, algo, limit })
        });

        const result = await response.json();
        if (result.success) {
            const data = result.data;
            await animateAndLog(data.traversalLog, data.results);

            const summary = document.createElement('li');
            summary.innerHTML = `<b>✅ Selesai!</b> Ditemukan <b>${data.results.length}</b> kecocokan dari <b>${data.visited}</b> node dikunjungi. Waktu: ${data.time.toFixed(2)}ms`;
            summary.style.cssText = 'margin-top:10px;text-align:center;padding:8px;background:#e8f5e0;border-radius:6px;';
            logList.appendChild(summary);
            logList.scrollTop = logList.scrollHeight;
        }
    } catch {
        alert("Terjadi kesalahan saat traversal.");
    } finally {
        traverseBtn.innerText = "Traverse";
        traverseBtn.disabled  = false;
    }
});

// ============ LCA BUTTON ============
lcaBtn.addEventListener('click', () => {
    if (!lcaMode) {
        // Enter LCA mode
        lcaMode     = true;
        lcaSelected = [];
        lcaStatusBar.style.display = 'flex';
        resetAllNodes();
        updateLCAChips();
        logList.innerHTML = '<li class="log-placeholder">🌿 Mode LCA — Klik 2 node pada pohon lalu tekan Traverse LCA.</li>';
    } else {
        // Run LCA if 2 nodes selected
        if (lcaSelected.length < 2) {
            alert("Pilih 2 node pada pohon terlebih dahulu!");
            return;
        }
        runLCA();
    }
});

lcaCancelBtn.addEventListener('click', () => {
    exitLCAMode();
    resetAllNodes();
});

function exitLCAMode() {
    lcaMode     = false;
    lcaSelected = [];
    lcaStatusBar.style.display = 'none';
    lcaBtn.innerHTML = lcaBtn.innerHTML; // refresh label
}

// ============ NODE CLICK (LCA selection) ============
function attachNodeClickHandler(id, el) {
    el.addEventListener('click', (e) => {
        if (!lcaMode) return;
        e.stopPropagation();

        const idx = lcaSelected.indexOf(id);
        if (idx !== -1) {
            // Deselect
            lcaSelected.splice(idx, 1);
            el.classList.remove('node-lca-selected');
        } else {
            if (lcaSelected.length >= 2) {
                // Replace oldest
                const old = lcaSelected.shift();
                if (nodeElements[old]) nodeElements[old].classList.remove('node-lca-selected');
            }
            lcaSelected.push(id);
            el.classList.add('node-lca-selected');
        }
        updateLCAChips();
    });
}

function updateLCAChips() {
    const n0 = lcaSelected[0];
    const n1 = lcaSelected[1];
    const tag0 = n0 !== undefined ? `&lt;${currentNodesData[n0]?.tagName}&gt; #${n0}` : '—';
    const tag1 = n1 !== undefined ? `&lt;${currentNodesData[n1]?.tagName}&gt; #${n1}` : '—';
    lcaChip1.innerHTML = `Node 1: <span>${tag0}</span>`;
    lcaChip2.innerHTML = `Node 2: <span>${tag1}</span>`;
    lcaChip1.classList.toggle('filled', n0 !== undefined);
    lcaChip2.classList.toggle('filled', n1 !== undefined);
}

// ============ RESET NODES ============
function resetAllNodes() {
    Object.values(nodeElements).forEach(el => {
        el.className = 'node-container';
    });
}

// ============ BINARY LIFTING LCA ============
function buildLCA(nodes) {
    const n = nodes.length;
    lcaDepth  = new Array(n).fill(0);
    lcaParent = Array.from({ length: LOG_BITS }, () => new Array(n).fill(-1));

    // BFS to set depth and immediate parent
    const visited = new Array(n).fill(false);
    const queue   = [0];
    visited[0]    = true;
    lcaParent[0][0] = 0;  // root is its own parent

    while (queue.length > 0) {
        const u = queue.shift();
        for (const c of (nodes[u].children || [])) {
            if (c < n && !visited[c]) {
                visited[c]      = true;
                lcaDepth[c]     = lcaDepth[u] + 1;
                lcaParent[0][c] = u;
                queue.push(c);
            }
        }
    }

    // Fill binary lifting table
    for (let k = 1; k < LOG_BITS; k++) {
        for (let v = 0; v < n; v++) {
            const p = lcaParent[k - 1][v];
            lcaParent[k][v] = p === -1 ? -1 : lcaParent[k - 1][p];
        }
    }
}

function queryLCA(u, v) {
    // Bring both to same depth
    if (lcaDepth[u] < lcaDepth[v]) [u, v] = [v, u];
    let diff = lcaDepth[u] - lcaDepth[v];
    for (let k = 0; k < LOG_BITS; k++) {
        if ((diff >> k) & 1) u = lcaParent[k][u];
    }
    if (u === v) return u;
    // Lift together
    for (let k = LOG_BITS - 1; k >= 0; k--) {
        if (lcaParent[k][u] !== lcaParent[k][v]) {
            u = lcaParent[k][u];
            v = lcaParent[k][v];
        }
    }
    return lcaParent[0][u];
}

function getAncestors(v) {
    const path = [];
    while (true) {
        const p = lcaParent[0][v];
        if (p === v) break;  // root
        path.push(p);
        v = p;
    }
    return path;
}

async function runLCA() {
    const [u, v] = lcaSelected;
    const lca    = queryLCA(u, v);
    const delay  = parseInt(speedSelect.value);

    // Get paths
    const pathU  = getPathToNode(u, lca);
    const pathV  = getPathToNode(v, lca);

    resetAllNodes();

    logList.innerHTML = '';
    const header = document.createElement('li');
    header.innerHTML = `<b>🌿 LCA Binary Lifting</b> — Node <b>#${u}</b> &amp; Node <b>#${v}</b>`;
    header.style.cssText = 'padding:6px;background:#e8f5e0;border-radius:6px;margin-bottom:4px;text-align:center;';
    logList.appendChild(header);

    // Animate path from u to LCA
    for (const id of pathU) {
        if (nodeElements[id]) {
            nodeElements[id].classList.add('node-lca-path');
            addLogItem(`↑ Naik dari #${id} &lt;${currentNodesData[id]?.tagName}&gt;`, '#5a8a3a');
            if (delay > 0) await sleep(delay);
        }
    }

    // Animate path from v to LCA
    for (const id of pathV) {
        if (nodeElements[id]) {
            nodeElements[id].classList.add('node-lca-path');
            addLogItem(`↑ Naik dari #${id} &lt;${currentNodesData[id]?.tagName}&gt;`, '#5a8a3a');
            if (delay > 0) await sleep(delay);
        }
    }

    // Keep selected nodes yellow
    if (nodeElements[u]) { nodeElements[u].classList.remove('node-lca-path'); nodeElements[u].classList.add('node-lca-selected'); }
    if (nodeElements[v]) { nodeElements[v].classList.remove('node-lca-path'); nodeElements[v].classList.add('node-lca-selected'); }

    // Highlight LCA result
    if (nodeElements[lca]) {
        nodeElements[lca].classList.remove('node-lca-path', 'node-lca-selected');
        nodeElements[lca].classList.add('node-lca-result');
    }

    const result = document.createElement('li');
    result.innerHTML = `<b>✅ LCA ditemukan:</b> Node <b>#${lca}</b> &lt;${currentNodesData[lca]?.tagName}&gt; (Depth: ${lcaDepth[lca]})`;
    result.style.cssText = 'margin-top:8px;padding:8px;background:#a9dfbf;border-radius:6px;text-align:center;font-weight:600;';
    logList.appendChild(result);
    logList.scrollTop = logList.scrollHeight;

    exitLCAMode();
}

function getPathToNode(from, to) {
    const path = [];
    let cur = from;
    while (cur !== to) {
        path.push(cur);
        cur = lcaParent[0][cur];
        if (cur === -1) break;
    }
    return path;
}

function addLogItem(html, color = '#333') {
    const li = document.createElement('li');
    li.innerHTML = html;
    li.style.color = color;
    logList.appendChild(li);
    logList.scrollTop = logList.scrollHeight;
}

function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
}

// ============ VISUALIZE TREE ============
function visualizeTree(nodes) {
    const NODE_W  = 110;
    const LEVEL_H = 90;
    nodeElements  = {};

    const renderCount = Math.min(nodes.length, MAX_VISUAL_NODES);

    function calcSubtreeWidth(id) {
        if (id >= renderCount) return NODE_W + 20;
        const node = nodes[id];
        if (!node || node.children.length === 0) return node.subtreeWidth = NODE_W + 20;
        let total = 0;
        for (const cid of node.children) {
            if (cid < renderCount) total += calcSubtreeWidth(cid);
        }
        return node.subtreeWidth = Math.max(total || NODE_W + 20, NODE_W + 20);
    }
    calcSubtreeWidth(0);

    const totalWidth = Math.max(3000, nodes[0].subtreeWidth + 200);
    treeContainer.style.width  = totalWidth + 'px';
    treeContainer.style.height = '3000px';

    function positionNode(id, x, y) {
        if (id >= renderCount) return;
        const node = nodes[id];
        if (!node) return;

        const isRoot = id === 0;

        if (!isRoot) {
            node.x = x; node.y = y;
            const div = document.createElement('div');
            div.className = 'node-container';
            div.style.left = (x - 50) + 'px';
            div.style.top  = y + 'px';
            div.title      = `<${node.tagName}> (ID: ${id}, Depth: ${lcaDepth[id] || 0})`;
            div.innerText  = `<${node.tagName}>`;
            treeContainer.appendChild(div);
            nodeElements[id] = div;
            attachNodeClickHandler(id, div);
        }

        const childY = isRoot ? y : y + LEVEL_H;
        let curX = x - (node.subtreeWidth || NODE_W + 20) / 2;
        for (const cid of node.children) {
            if (cid >= renderCount) continue;
            const w = nodes[cid].subtreeWidth || NODE_W + 20;
            positionNode(cid, curX + w / 2, childY);
            curX += w;
        }
    }

    positionNode(0, Math.max(1500, (nodes[0].subtreeWidth || 3000) / 2), 20);
    drawLines();

    if (nodes.length > MAX_VISUAL_NODES) {
        const notice = document.createElement('div');
        notice.style.cssText = 'position:absolute;top:5px;left:10px;background:#fff3cd;border:1.5px solid #f9a825;padding:5px 12px;border-radius:6px;font-size:12px;z-index:20;color:#7d4e00;';
        notice.innerText = `⚠ Ditampilkan ${MAX_VISUAL_NODES} dari ${nodes.length} node.`;
        treeContainer.appendChild(notice);
    }
}

function drawLines() {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("style", "position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:0;");
    treeContainer.prepend(svg);

    for (const node of currentNodesData) {
        if (!nodeElements[node.id]) continue;
        for (const cid of node.children) {
            if (!nodeElements[cid]) continue;
            const child = currentNodesData[cid];
            const midY  = (node.y + 30 + child.y) / 2;
            const path  = document.createElementNS("http://www.w3.org/2000/svg", "path");
            path.setAttribute("d", `M ${node.x} ${node.y + 30} L ${node.x} ${midY} L ${child.x} ${midY} L ${child.x} ${child.y}`);
            path.setAttribute("stroke", "#c5dfc0");
            path.setAttribute("stroke-width", "1.5");
            path.setAttribute("fill", "none");
            svg.appendChild(path);
        }
    }
}

// ============ ANIMATE & LOG (Traverse) ============
async function animateAndLog(logIds, targetIds) {
    const delay      = parseInt(speedSelect.value);
    const targets    = new Set(targetIds);
    const useAnim    = delay > 0 && logIds.length <= 2000;

    let step = 1;
    for (const id of logIds) {
        if (id === 0) continue;
        const node    = currentNodesData[id];
        if (!node) { step++; continue; }

        const isMatch = targets.has(id);
        const el      = nodeElements[id];

        if (el) {
            el.classList.remove('node-visited', 'node-match');
            el.classList.add(isMatch ? 'node-match' : 'node-visited');
        }

        if (step <= MAX_LOG_ENTRIES) {
            const li = document.createElement('li');
            li.className = isMatch ? 'log-item-match' : 'log-item-visit';
            li.innerText = `[${step}] <${node.tagName}> (ID:${id})${isMatch ? " ✅ MATCH!" : ""}`;
            logList.appendChild(li);
            logList.scrollTop = logList.scrollHeight;
        } else if (step === MAX_LOG_ENTRIES + 1) {
            const li = document.createElement('li');
            li.className = 'log-placeholder';
            li.innerText = `... ${logIds.length - MAX_LOG_ENTRIES} langkah lagi tidak ditampilkan`;
            logList.appendChild(li);
        }

        if (useAnim) await sleep(delay);
        step++;
    }

    if (!useAnim) await sleep(0);
}
